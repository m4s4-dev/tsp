import sys
from pathlib import Path
from xbmcaddon import Addon

PLUGIN_URL = sys.argv[0]
ADDON_HANDLE = int(sys.argv[1])
QUERYSTRING = sys.argv[2]

ADDON_ID = "plugin.video.thestreamerpro"
ADDON_PATH = Path(Addon().getAddonInfo("path"))

WEBPAGES_PATH = ADDON_PATH / "webserver"
VISIBILITY_PATH = ADDON_PATH / "resources/data/addons_visibility.txt"
SOURCESFILE_XML = "special://profile/sources.xml"

DEFAULT_ICON = (ADDON_PATH / "resources/images/icon.png").as_posix()
DEFAULT_THUMB = (ADDON_PATH / "resources/images/thumb.png").as_posix()
DEFAULT_FANART = (ADDON_PATH / "resources/images/fanart.jpg").as_posix()