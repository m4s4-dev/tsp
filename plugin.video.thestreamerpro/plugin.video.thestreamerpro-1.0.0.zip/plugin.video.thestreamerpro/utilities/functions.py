import json, base64, xbmcvfs
from pathlib import Path
from utilities.variables import ADDON_ID, ADDON_PATH


# ============================================================
# Link encoding

def encode_link_data(link):
    raw = json.dumps(link, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii")


def decode_link_data(encoded):
    raw = base64.urlsafe_b64decode(encoded.encode("ascii"))
    return json.loads(raw.decode("utf-8"))


# ============================================================
# Plugin URLs

def build_url(link):
    return f"plugin://{ADDON_ID}/?data={encode_link_data(link)}"


def build_url_trdparty(link):
    return f"plugin://{link['addon_id']}/{link['querystring']}"


# ============================================================
# Paths / files

def make_abs_path(path):
    path = Path(path)
    return path if path.is_absolute() else ADDON_PATH / path


def make_abs_path_from_special(path):
    return xbmcvfs.translatePath(path)


def file_exists(path):
    return xbmcvfs.exists(str(path))


def read_file(path):
    with xbmcvfs.File(str(path)) as f:
        return f.read()


def write_file(path, content):
    with xbmcvfs.File(str(path), "w") as f:
        f.write(content)

def ensure_file(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.touch()


def read_text_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def write_text_file(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


# ============================================================
# JSON

def get_json_object(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
