# utilities/contracts.py

from utilities.variables import DEFAULT_ICON, DEFAULT_FANART, DEFAULT_THUMB

# =============================================================

def contract_page(title=None, items=None):
    return {
        "title": title,
        "items": items
    }

# =============================================================

def contract_item(
    label="No Name",
    link=None,
    plot="",
    is_folder=True,
    art_thumb=DEFAULT_THUMB,
    art_icon=DEFAULT_ICON,
    art_fanart=DEFAULT_FANART
):

    art = {"thumb": art_thumb, "icon": art_icon, "fanart": art_fanart}
        
    item = {
        "label": label,
        "link": link,
        "plot": plot,
        "art": art,
        "is_folder": is_folder
    }

    return item

# =============================================================

def contract_link(action, **params):
    return {
        "action": action,
        **params
    }


def contract_link_trdparty(addon_id, querystring=""):
    return {
        "is_trdparty": True,
        "addon_id": addon_id,
        "querystring": querystring,
    }

# =============================================================
