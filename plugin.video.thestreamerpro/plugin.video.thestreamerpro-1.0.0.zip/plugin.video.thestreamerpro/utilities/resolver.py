# utilities/resolver.py

import resolveurl

# ============================================================

def get_link_from_magnet(magnet):
    hmf = resolveurl.HostedMediaFile(
        magnet,
        return_all=True
    )
    files = hmf.resolve()
    return files

# ============================================================

def resolve_link(link):
    return resolveurl.resolve(link)
