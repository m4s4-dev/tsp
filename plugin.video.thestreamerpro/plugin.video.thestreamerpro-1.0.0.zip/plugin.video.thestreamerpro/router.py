from urllib.parse import parse_qsl
from importlib import import_module
from utilities.functions import decode_link_data

ACTIONS = {
    "home": "actions.home.home",
    "trdp": "actions.third_party.trdp",
    "urlx": "actions.url_player.urlx",
}


def get_params_from_qstring(querystring):
    if not querystring.startswith("?"):
        return {}
    params = dict(parse_qsl(querystring[1:]))
    return decode_link_data(params["data"])


def router(querystring):
    params = get_params_from_qstring(querystring)
    action_id = params.get("action") or "home"
    module = import_module(ACTIONS[action_id])
    handler = getattr(module, f"{action_id}_action")
    handler()