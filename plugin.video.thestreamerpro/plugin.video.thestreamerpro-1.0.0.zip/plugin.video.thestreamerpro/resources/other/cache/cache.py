from datetime import timedelta
from simplecache import SimpleCache

_cache = None

def _ensure_cache():
    global _cache
    if _cache is None:
        _cache = SimpleCache()
    return _cache

def cache_get(key):
    return _ensure_cache().get(key)

def cache_set(key, value, ttl=3600):
    return _ensure_cache().set(
        key,
        value,
        expiration=timedelta(seconds=ttl)
    )

def cache_delete(key):
    return _ensure_cache().delete(key)

def cache_clear():
    return _ensure_cache().empty()