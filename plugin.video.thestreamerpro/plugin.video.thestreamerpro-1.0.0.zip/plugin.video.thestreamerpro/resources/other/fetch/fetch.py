# engine/managers/fetch/fetch.py

import requests
from engine.managers.cache.cache import cache_get, cache_set

# ----------------------------------------------------------------------
# Fetch con cache
# ----------------------------------------------------------------------

def cached_fetch(url, cache_key, ttl=3600):
    cached = cache_get(cache_key)
    if cached is not None:
        return cached
    html = get_html(url)
    cache_set(cache_key, html, ttl=ttl)
    return html

# ======================================================================

def get_html(url, timeout=30):
    headers = {
        "User-Agent": "Mozilla/5.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Connection": "close",
    }
    resp = requests.get(
        url,
        headers=headers,
        timeout=(5, timeout),
        allow_redirects=True
    )
    resp.raise_for_status()
    if not resp.encoding:
        resp.encoding = "utf-8"
    return resp.text