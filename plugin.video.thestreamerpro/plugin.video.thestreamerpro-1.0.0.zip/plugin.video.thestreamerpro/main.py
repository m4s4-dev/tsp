# main.py

from router import router
from utilities.variables import QUERYSTRING

if __name__ == "__main__":
    router(QUERYSTRING)