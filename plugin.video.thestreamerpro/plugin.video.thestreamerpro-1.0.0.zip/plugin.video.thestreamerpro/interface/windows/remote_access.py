import xbmcgui

# ============================================================

CONTROL_URL = 1000
CONTROL_CLOSE = 9000

# ============================================================

class RemoteAccessWindow(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, url="", **kwargs):
        super().__init__(*args, **kwargs)
        self.url = url
        self.closed_by_user = False

    def onInit(self):
        self.getControl(CONTROL_URL).setLabel(str(self.url))

    def onClick(self, control_id):
        if control_id == CONTROL_CLOSE:
            self.closed_by_user = True
            self.close()