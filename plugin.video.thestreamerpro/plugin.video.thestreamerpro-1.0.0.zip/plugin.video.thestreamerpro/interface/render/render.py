# interface/render/render.py

import xbmc, xbmcgui, xbmcplugin
from interface.render.helpers import *

# ======================================================================

def render_page(page):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, page["title"])
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    for item in page["items"]:
        render_item(item)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)

# ======================================================================

def render_play(play_url, label="Player"):
    li = xbmcgui.ListItem(label)
    li.setInfo("video", {"title": label})
    xbmc.Player().play(play_url, li)

# ======================================================================

def render_text(heading, text):
    xbmcgui.Dialog().textviewer(heading, text)

# ======================================================================

def render_notification(heading, message, type="info", time=3000):
    icon = {
        "info": xbmcgui.NOTIFICATION_INFO,
        "error": xbmcgui.NOTIFICATION_ERROR
    }
    xbmcgui.Dialog().notification(heading, message, icon[type], time)

# ======================================================================

def render_input(heading="Input string"):
    text = xbmcgui.Dialog().input(heading, type=xbmcgui.INPUT_ALPHANUM)
    if not text or not text.strip():
        return None
    return text.strip()

def render_search_keyboard(heading="Search"):
    keyboard = xbmc.Keyboard("", heading)
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return None
    text = keyboard.getText()
    if not text or not text.strip():
        return None
    return text.strip()

# =====================================================================

def render_select(heading, options):
    labels = []
    for option in options:
        if isinstance(option, str):
            labels.append(option)
        elif isinstance(option, dict):
            labels.append(list(option.keys())[0])
        elif isinstance(option, (tuple, list)):
            labels.append(str(option[0]))
        else:
            labels.append(str(option))
    idx = xbmcgui.Dialog().select(heading, labels)
    return idx if idx >= 0 else None

# ======================================================================

def render_multiselect(
    heading,
    options,
    preselect=None
):

    idxs = xbmcgui.Dialog().multiselect(
        heading,
        options,
        preselect=preselect
    )

    return idxs if idxs is not None else []

# ======================================================================

def render_ok(heading, message):
    xbmcgui.Dialog().ok(heading, message)