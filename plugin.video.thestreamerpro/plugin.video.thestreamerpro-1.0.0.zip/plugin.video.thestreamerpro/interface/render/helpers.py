# interface/render/helpers.py

import xbmcgui, xbmcplugin
from utilities.variables import ADDON_HANDLE
from utilities.functions import build_url, build_url_trdparty

# ======================================================================

def render_item(item):
    li = xbmcgui.ListItem(label=item["label"])
    li.setArt(item["art"])
    li.setInfo("video", {
        "title": item["label"],
        "plot": item["plot"]
    })
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=get_item_url(item["link"]),
        listitem=li,
        isFolder=item["is_folder"]
    )

# ======================================================================

def get_item_url(link):
    if link.get("is_trdparty"):
        return build_url_trdparty(link)
    return build_url(link)
