import json, xbmc

from utilities.variables import VISIBILITY_PATH
from utilities.functions import ensure_file, read_text_file, write_text_file


def get_installed_video_addons():
    response = xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0",
        "method": "Addons.GetAddons",
        "params": {
            "type": "xbmc.python.pluginsource",
            "properties": ["name"]
        },
        "id": 1
    }))
    addons = json.loads(response)["result"]["addons"]
    return [
        {"id": addon["addonid"], "name": addon["name"]}
        for addon in addons
    ]


def get_visible_addon_ids():
    ensure_file(VISIBILITY_PATH)
    return {
        line.strip()
        for line in read_text_file(VISIBILITY_PATH).splitlines()
        if line.strip()
    }


def save_visible_addon_ids(addon_ids):
    ensure_file(VISIBILITY_PATH)
    write_text_file(VISIBILITY_PATH, "\n".join(sorted(addon_ids)))


def get_visible_video_addons():
    visible_ids = get_visible_addon_ids()
    return [
        addon
        for addon in get_installed_video_addons()
        if addon["id"] in visible_ids
    ]