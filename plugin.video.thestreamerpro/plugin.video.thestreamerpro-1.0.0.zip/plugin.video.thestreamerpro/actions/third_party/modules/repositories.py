from utilities.variables import SOURCESFILE_XML
from utilities.functions import (
    file_exists,
    read_file,
    write_file,
    make_abs_path_from_special
)


def add_repo_to_sources_xml(name, url):
    sources_path = make_abs_path_from_special(SOURCESFILE_XML)
    ensure_sources_xml(sources_path)
    sources_xml = read_file(sources_path)
    if is_repo_in_sources_xml(url, sources_xml):
        return
    write_file(sources_path, inject_repo_source(name, url, sources_xml))


def ensure_sources_xml(path):
    if not file_exists(path):
        write_file(path, create_sources_xml())


def is_repo_in_sources_xml(repo_url, sources_xml):
    return repo_url in sources_xml


def inject_repo_source(name, url, sources_xml):
    source_xml = (
        "    <source>\n"
        f"        <name>[TSP]{name}[/TSP]</name>\n"
        f"        <path pathversion=\"1\">{url}</path>\n"
        "        <allowsharing>true</allowsharing>\n"
        "    </source>\n"
    )
    return sources_xml.replace("</files>", f"{source_xml}\n</files>")


def create_sources_xml():
    return (
        "<sources>\n"
        "    <programs></programs>\n"
        "    <video></video>\n"
        "    <music></music>\n"
        "    <pictures></pictures>\n"
        "    <files></files>\n"
        "</sources>\n"
    )