from interface.render.render import (
    render_input,
    render_multiselect,
    render_ok,
    render_page,
    render_select,
)
from services.remote_input import get_remote_input
from utilities.contracts import (
    contract_item,
    contract_link_trdparty,
    contract_page,
)

from actions.third_party.modules.addons import (
    get_installed_video_addons,
    get_visible_addon_ids,
    get_visible_video_addons,
    save_visible_addon_ids,
)
from actions.third_party.modules.repositories import add_repo_to_sources_xml


REMOTE_INPUT_PAGE = "third_party"


# ======================================================================
# Action

def trdp_action():
    selected = render_select(
        "Third-Party Addons",
        [
            "Show Enabled Addons",
            "Manage Addons Visibility",
            "Add Repository (Local)",
            "Add Repository (Remote)",
        ],
    )

    if selected is None:
        return

    if selected == 0:
        show_enabled_addons()

    elif selected == 1:
        manage_addons_visibility()

    elif selected == 2:
        add_local_repository()

    elif selected == 3:
        add_remote_repositories()


# ======================================================================
# Addons

def show_enabled_addons():
    addons = get_visible_video_addons()

    items = [
        contract_item(
            label=f"{addon['name']} ({addon['id']})",
            plot=addon["id"],
            link=contract_link_trdparty(addon["id"]),
            is_folder=True,
        )
        for addon in addons
    ]

    render_page(
        contract_page(
            title="Visible Addons",
            items=items,
        )
    )


def manage_addons_visibility():
    addons = get_installed_video_addons()
    visible_ids = get_visible_addon_ids()

    labels = [addon["name"] for addon in addons]

    preselect = [
        index
        for index, addon in enumerate(addons)
        if addon["id"] in visible_ids
    ]

    selected_indexes = render_multiselect(
        "Choose visible addons",
        labels,
        preselect=preselect,
    )

    selected_ids = [
        addons[index]["id"]
        for index in selected_indexes
    ]

    save_visible_addon_ids(selected_ids)
    render_ok("Addons", "Visibility updated.")


# ======================================================================
# Repositories

def add_local_repository():
    url = render_input("Repository URL")

    if not url:
        return

    name = render_input("Repository Name")

    if not name:
        return

    add_repositories([
        {
            "name": name,
            "url": url,
        }
    ])


def add_remote_repositories():
    data = get_remote_input(REMOTE_INPUT_PAGE)

    if not data:
        return

    add_repositories(data["repositories"])


def add_repositories(repositories):
    for repository in repositories:
        add_repo_to_sources_xml(
            repository["name"],
            repository["url"],
        )

    render_ok("Repository", "Repositories added.")