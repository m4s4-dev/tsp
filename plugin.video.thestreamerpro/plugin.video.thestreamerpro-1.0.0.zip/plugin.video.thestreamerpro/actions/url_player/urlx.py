from interface.render.render import render_input, render_play, render_select
from services.remote_input import get_remote_input
from utilities.resolver import get_link_from_magnet, resolve_link


REMOTE_INPUT_PAGE = "url_player"


# ======================================================================
# Action

def urlx_action():
    input_type = render_select(
        "Choose input method",
        [
            "Local Input URL",
            "Remote Input URL",
        ],
    )

    if input_type is None:
        return

    if input_type == 0:
        url = render_input("URL")
    else:
        url = get_remote_url()

    if not url:
        return

    resolve_and_play(url)


# ======================================================================
# Helpers

def get_remote_url():
    data = get_remote_input(REMOTE_INPUT_PAGE)

    if not data:
        return None

    return data["url"]


def resolve_and_play(url):
    url = url.strip()
    play_url = url

    if is_magnet(url):
        files = get_link_from_magnet(url)
        index = render_select("Choose file", files)

        if index is None:
            return

        play_url = resolve_link(files[index])

    elif is_resolvable(url):
        resolved_url = resolve_link(url)

        if resolved_url:
            play_url = resolved_url

    render_play(play_url, label="Play")


def is_magnet(url):
    return url.lower().startswith("magnet:")


def is_resolvable(url):
    return url.lower().startswith(("http://", "https://"))