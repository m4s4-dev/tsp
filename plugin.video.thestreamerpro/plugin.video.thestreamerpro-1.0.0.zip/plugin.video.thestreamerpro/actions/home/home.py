from interface.render.render import render_page
from utilities.contracts import contract_page, contract_item, contract_link


def home_action():
    render_page(contract_page("Home", get_home_items()))


def get_home_items():
    return [
        contract_item(
            label="Play External URL",
            plot="Play media from an external URL.",
            link=contract_link(action="urlx")
        ),
        contract_item(
            label="Third-Party Addons",
            plot="Explore third-party addons.",
            link=contract_link(action="trdp")
        )
    ]