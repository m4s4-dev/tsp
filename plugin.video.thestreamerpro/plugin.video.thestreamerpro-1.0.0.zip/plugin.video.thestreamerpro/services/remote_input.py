from threading import Thread

from interface.windows.remote_access import RemoteAccessWindow
from utilities.variables import ADDON_PATH
from webserver.server import start, stop, wait


# ======================================================================
# Parsers

def parse_url_player(data):
    return {
        "url": data["content-url-input"],
    }


def parse_third_party(data):
    return {
        "repositories": [
            {
                "name": repository["repo-name-input"],
                "url": repository["repo-url-input"],
            }
            for repository in data["repos"]
        ],
    }


PARSERS = {
    "url_player": parse_url_player,
    "third_party": parse_third_party,
}


# ======================================================================
# Remote input

def get_remote_input(page_name):
    response_data = {}

    session = start(
        "user_input",
        request_data={"action_name": page_name},
    )

    window = RemoteAccessWindow(
        "RemoteAccessDialog.xml",
        ADDON_PATH.as_posix(),
        "default",
        "1080i",
        url=session["url"],
    )

    worker = Thread(
        target=wait_remote_input,
        args=(session, window, response_data),
        daemon=True,
    )
    worker.start()

    window.doModal()

    if window.closed_by_user:
        stop(session)

    if not response_data:
        return None

    return PARSERS[page_name](response_data)


def wait_remote_input(session, window, response_data):
    response_data.update(wait(session))
    window.close()

