const form = document.getElementById("input-form");

const urlPlayerSection = document.getElementById("url-player");
const thirdPartySection = document.getElementById("third-party");

const contentUrlInput = document.getElementById("content-url-input");

const repositoriesContainer = document.getElementById("repositories");
const repositoryTemplate = document.getElementById("repository-template");
const addRepositoryButton = document.getElementById("add-repository");


function initializePage() {
    if (ACTION_NAME === "url_player") {
        urlPlayerSection.hidden = false;
        return;
    }

    if (ACTION_NAME === "third_party") {
        thirdPartySection.hidden = false;
        addRepository();
        return;
    }

    throw new Error(`Unknown action: ${ACTION_NAME}`);
}


function addRepository() {
    const repository = repositoryTemplate.content.firstElementChild.cloneNode(true);

    repository
        .querySelector(".remove-repository")
        .addEventListener("click", () => {
            repository.remove();
        });

    repositoriesContainer.appendChild(repository);
}


function getUrlPlayerData() {
    const url = contentUrlInput.value.trim();

    if (!url) {
        throw new Error("URL is required.");
    }

    return {
        "content-url-input": url,
    };
}


function getThirdPartyData() {
    const repositories = [
        ...repositoriesContainer.querySelectorAll(".repository"),
    ].map(repository => ({
        "repo-name-input": repository
            .querySelector(".repository-name")
            .value
            .trim(),

        "repo-url-input": repository
            .querySelector(".repository-url")
            .value
            .trim(),
    }));

    if (!repositories.length) {
        throw new Error("Add at least one repository.");
    }

    const hasInvalidRepository = repositories.some(repository =>
        !repository["repo-name-input"] ||
        !repository["repo-url-input"]
    );

    if (hasInvalidRepository) {
        throw new Error("Repository name and URL are required.");
    }

    return {
        repos: repositories,
    };
}


function getRequestData() {
    if (ACTION_NAME === "url_player") {
        return getUrlPlayerData();
    }

    if (ACTION_NAME === "third_party") {
        return getThirdPartyData();
    }

    throw new Error(`Unknown action: ${ACTION_NAME}`);
}


async function submitForm(event) {
    event.preventDefault();

    try {
        const data = getRequestData();

        const response = await fetch("/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        });

        if (!response.ok) {
            throw new Error("Unable to send data.");
        }

        showSuccess();
    } catch (error) {
        alert(error.message);
    }
}


function showSuccess() {
    document.body.innerHTML = `
        <main class="container py-5">
            <h1>Received</h1>
            <p>You can close this page.</p>
        </main>
    `;
}


addRepositoryButton.addEventListener("click", addRepository);
form.addEventListener("submit", submitForm);

initializePage();