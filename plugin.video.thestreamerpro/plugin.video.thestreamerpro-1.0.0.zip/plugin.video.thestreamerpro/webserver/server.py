import json
import socket

import xbmc

from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs

from utilities.variables import WEBPAGES_PATH


CONTENT_TYPES = {
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
}


# ======================================================================
# Request handler

class Handler(BaseHTTPRequestHandler):

    page_path = None
    request_data = {}
    response_data = None

    def do_GET(self):
        file_path = get_request_file_path(
            self.path,
            self.page_path,
        )

        if not file_path.exists():
            self.send_error(404)
            return

        content = file_path.read_text(encoding="utf-8")
        content = inject_request_data(
            content,
            self.request_data,
        )

        self.send_response(200)
        self.send_header(
            "Content-Type",
            get_content_type(file_path),
        )
        self.end_headers()

        self.wfile.write(content.encode("utf-8"))

    def do_POST(self):
        data = read_request_data(self)

        self.response_data.update(data)

        self.send_response(200)
        self.send_header(
            "Content-Type",
            "text/html; charset=utf-8",
        )
        self.end_headers()

        self.wfile.write(
            b"Received. You can close this page."
        )

    def log_message(self, format, *args):
        return


# ======================================================================
# Server

def start(page_name, request_data=None, port=8787):
    response_data = {}

    Handler.page_path = WEBPAGES_PATH / page_name
    Handler.request_data = request_data or {}
    Handler.response_data = response_data

    server = HTTPServer(("", port), Handler)
    server.timeout = 1

    return {
        "server": server,
        "response_data": response_data,
        "url": f"http://{get_local_ip()}:{port}",
    }


def wait(session):
    server = session["server"]
    response_data = session["response_data"]
    monitor = xbmc.Monitor()

    while not monitor.abortRequested():
        if response_data:
            break

        server.handle_request()

    stop(session)

    return response_data


def stop(session):
    session["server"].server_close()


# ======================================================================
# Request helpers

def read_request_data(handler):
    content_length = int(
        handler.headers.get("Content-Length", 0)
    )

    body = handler.rfile.read(content_length).decode("utf-8")
    content_type = handler.headers.get("Content-Type", "")

    if "application/json" in content_type:
        return json.loads(body)

    parsed_data = parse_qs(body)

    return {
        key: values[0].strip()
        for key, values in parsed_data.items()
    }


def inject_request_data(content, request_data):
    for key, value in request_data.items():
        content = content.replace(
            f"{{{{{key}}}}}",
            str(value),
        )

    return content


def get_request_file_path(request_path, page_path):
    if request_path in ("", "/"):
        return page_path / "index.html"

    return page_path / request_path.lstrip("/")


def get_content_type(file_path):
    return CONTENT_TYPES.get(
        file_path.suffix,
        "text/html; charset=utf-8",
    )


# ======================================================================
# Network

def get_local_ip():
    hostname = socket.gethostname()
    ips = socket.gethostbyname_ex(hostname)[2]

    for ip in ips:
        if ip.startswith(("192.168.", "10.", "172.")):
            return ip

    return "127.0.0.1"